import javax.swing.SwingUtilities;
import view.BibliotecaView;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BibliotecaView vista = new BibliotecaView();
            vista.setVisible(true);
        });
    }
}