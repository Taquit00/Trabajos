/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import tallerstack.model.Libro;
import tallerstack.model.PilaLibros;

public class BibliotecaController {

    private PilaLibros pilaLibros;

    public BibliotecaController() {
        pilaLibros = new PilaLibros();
    }

    // Registrar un nuevo libro
    public void apilarLibro(String codigo, String nombre, String autor,
            String editorial, int anio) {
        Libro libro = new Libro(codigo, nombre, autor, editorial, anio);
        pilaLibros.apilar(libro);
    }

    // Sacar el libro del tope
    public Libro sacarLibro() {
        return pilaLibros.desapilar();
    }

    // Obtener la representación gráfica del estante
    public String obtenerVistaEstante() {
        return pilaLibros.mostrarPila();
    }

    // Ver libro del tope
    public Libro verTope() {
        return pilaLibros.verTope();
    }

    // Cantidad de libros
    public int cantidadLibros() {
        return pilaLibros.size();
    }

    // Verificar si está vacío
    public boolean estaVacio() {
        return pilaLibros.estaVacia();
    }
}
