package tallerstack.model;

public class Libro {

    private String codigo;
    private String nombre;
    private String autor;
    private String editorial;
    private int Publicacion;

    public Libro(String codigo, String nombre, String autor,
            String editorial, int Publicacion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.autor = autor;
        this.editorial = editorial;
        this.Publicacion = Publicacion;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAutor() {
        return autor;
    }

    public String getEditorial() {
        return editorial;
    }

    public int getPublicacion() {
        return Publicacion;
    }

    @Override
    public String toString() {
        return nombre + " (" + codigo + ")";
    }
}
