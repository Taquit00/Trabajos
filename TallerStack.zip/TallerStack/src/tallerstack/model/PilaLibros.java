/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tallerstack.model;


import java.util.Stack;

public class PilaLibros {

    private Stack<Libro> pila;

    public PilaLibros() {
        pila = new Stack<>();
    }

    // Apilar un libro
    public void apilar(Libro libro) {
        pila.push(libro);
    }

    // Sacar el libro del tope
    public Libro desapilar() {
        if (!pila.isEmpty()) {
            return pila.pop();
        }
        return null;
    }

    // Ver el libro del tope sin retirarlo
    public Libro verTope() {
        if (!pila.isEmpty()) {
            return pila.peek();
        }
        return null;
    }

    // Verificar si la pila está vacía
    public boolean estaVacia() {
        return pila.isEmpty();
    }

    // Cantidad de libros
    public int size() {
        return pila.size();
    }

    // Mostrar el contenido de la pila
    public String mostrarPila() {
        if (pila.isEmpty()) {
            return "El estante está vacío.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("=== TOPE DEL ESTANTE ===\n\n");

        for (int i = pila.size() - 1; i >= 0; i--) {
            Libro libro = pila.get(i);
            sb.append("📘 ").append(libro.toString()).append("\n");
        }

        sb.append("\n=== BASE DEL ESTANTE ===");
        return sb.toString();
    }
}
