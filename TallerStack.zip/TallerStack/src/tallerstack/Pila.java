/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tallerstack;

import java.util.Scanner;
import java.util.Stack;


public class Pila {
    public static void main(String[] args) {
        Stack<String> pila = new Stack<>();
        Scanner input= new Scanner(System.in);
        System.out.println("ingrese un libro");
        String str=input.nextLine();
        
        // Insertar elementos        
        pila.push("Libro 1");
        pila.push("Libro 2");
        pila.push(str);
        
        // Consultar la cima (Libro 3)
        System.out.println("Cima: " + pila.peek());
        
        // Eliminar elemento (sale Libro 3)
        System.out.println("Extraído: " + pila.pop());
    }
}

