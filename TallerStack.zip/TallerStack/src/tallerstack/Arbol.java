/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tallerstack;

/**
 *
 * @author UIS
 */
class Nodo {
    int valor;
    Nodo izquierdo, derecho;

    public Nodo(int item) {
        valor = item;
        izquierdo = derecho = null;
    }
}

public class Arbol {
    Nodo raiz;

    Arbol(int valor) {
        raiz = new Nodo(valor);
    }

    Arbol() {
        raiz = null;
    }

    public static void main(String[] args) {
        Arbol arbol = new Arbol();
        
        arbol.raiz = new Nodo(1); // Raíz
        arbol.raiz.izquierdo = new Nodo(2); // Hijo izquierdo
        arbol.raiz.derecho = new Nodo(3); // Hijo derecho
        
        System.out.println("Raíz del árbol: " + arbol.raiz.valor);
    }
}
