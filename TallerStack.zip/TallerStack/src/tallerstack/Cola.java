/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tallerstack;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Cola {
    public static void main(String[] args) {
        Queue<String> cola = new LinkedList<>();
        Scanner input= new Scanner(System.in);
        System.out.println("ingrese un cliente");
        String str=input.nextLine();
        // Insertar elementos
        
        cola.offer("Cliente 2");
        cola.offer(str);
        // Consultar el frente (Cliente 1)
        System.out.println("Frente: " + cola.peek());
        
        // Atender al cliente (sale Cliente 1)
        System.out.println("Atendido: " + cola.poll());
    }
}
