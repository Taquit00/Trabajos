/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.BibliotecaController;
import tallerstack.model.Libro;

public class ScreenManager {

    private BibliotecaController controller;

    public ScreenManager() {
        controller = new BibliotecaController();
    }

    // Método para agregar libro desde la interfaz
    public void agregarLibro(String codigo, String nombre,
            String autor, String editorial,
            int año) {
        controller.apilarLibro(codigo, nombre, autor, editorial, año);
    }

    // Método para retirar libro desde la interfaz
    public String retirarLibro() {
        Libro libro = controller.sacarLibro();

        if (libro == null) {
            return "No hay libros en el estante.";
        }

        return "Se retiró: " + libro.toString();
    }

    // Método para mostrar el estante en un JTextArea
    public String mostrarEstante() {
        return controller.obtenerVistaEstante();
    }

    // Método para mostrar el libro del tope
    public String mostrarTope() {
        Libro libro = controller.verTope();

        if (libro == null) {
            return "El estante está vacío.";
        }

        return "Libro en el tope: " + libro.toString();
    }

    // Cantidad de libros
    public int getCantidadLibros() {
        return controller.cantidadLibros();
    }

    // Verificar si está vacío
    public boolean estaVacio() {
        return controller.estaVacio();
    }
}
