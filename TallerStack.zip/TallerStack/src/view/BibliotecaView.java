package view;

import javax.swing.*;
import java.awt.*;

public class BibliotecaView extends JFrame {

    private ScreenManager screenManager;

    // Campos de texto
    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtAutor;
    private JTextField txtEditorial;
    private JTextField txtAnio;

    // Área para mostrar la pila
    private JTextArea txtAreaEstante;

    // Etiqueta de cantidad
    private JLabel lblCantidad;

    // Botones
    private JButton btnApilar;
    private JButton btnSacar;
    private JButton btnVerTope;
    private JButton btnLimpiar;

    public BibliotecaView() {
        screenManager = new ScreenManager();
        initComponents();
        actualizarVista();
    }

    private void initComponents() {
        setTitle("Biblioteca UIS - Gestión de Libros con Pila");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // =====================================================
        // PANEL IZQUIERDO - FORMULARIO
        // =====================================================
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBorder(BorderFactory.createTitledBorder("Datos del Libro"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Etiquetas y campos
        txtCodigo = new JTextField(20);
        txtNombre = new JTextField(20);
        txtAutor = new JTextField(20);
        txtEditorial = new JTextField(20);
        txtAnio = new JTextField(20);

        agregarCampo(panelFormulario, gbc, 0, "Código:", txtCodigo);
        agregarCampo(panelFormulario, gbc, 1, "Nombre:", txtNombre);
        agregarCampo(panelFormulario, gbc, 2, "Autor:", txtAutor);
        agregarCampo(panelFormulario, gbc, 3, "Editorial:", txtEditorial);
        agregarCampo(panelFormulario, gbc, 4, "Año de publicación:", txtAnio);

        // Botones
        btnApilar = new JButton("Apilar Libro");
        btnSacar = new JButton("Sacar Libro");
        btnVerTope = new JButton("Ver Tope");
        btnLimpiar = new JButton("Limpiar Campos");

        JPanel panelBotones = new JPanel(new GridLayout(4, 1, 5, 5));
        panelBotones.add(btnApilar);
        panelBotones.add(btnSacar);
        panelBotones.add(btnVerTope);
        panelBotones.add(btnLimpiar);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panelFormulario.add(panelBotones, gbc);

        // =====================================================
        // PANEL DERECHO - VISUALIZACIÓN DE LA PILA
        // =====================================================
        JPanel panelEstante = new JPanel(new BorderLayout());
        panelEstante.setBorder(BorderFactory.createTitledBorder("Estante Vertical (Pila)"));

        txtAreaEstante = new JTextArea();
        txtAreaEstante.setEditable(false);
        txtAreaEstante.setFont(new Font("Monospaced", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(txtAreaEstante);
        panelEstante.add(scrollPane, BorderLayout.CENTER);

        lblCantidad = new JLabel("Cantidad de libros: 0");
        lblCantidad.setFont(new Font("Arial", Font.BOLD, 14));
        lblCantidad.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelEstante.add(lblCantidad, BorderLayout.SOUTH);

        // =====================================================
        // AGREGAR PANELES PRINCIPALES
        // =====================================================
        add(panelFormulario, BorderLayout.WEST);
        add(panelEstante, BorderLayout.CENTER);

        // =====================================================
        // EVENTOS
        // =====================================================
        btnApilar.addActionListener(e -> apilarLibro());
        btnSacar.addActionListener(e -> sacarLibro());
        btnVerTope.addActionListener(e -> verTope());
        btnLimpiar.addActionListener(e -> limpiarCampos());
    }

    private void agregarCampo(JPanel panel, GridBagConstraints gbc,
            int fila, String etiqueta, JTextField campo) {

        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.gridwidth = 1;
        panel.add(new JLabel(etiqueta), gbc);

        gbc.gridx = 1;
        panel.add(campo, gbc);
    }

    // =====================================================
    // MÉTODOS DE ACCIÓN
    // =====================================================
    private void apilarLibro() {
        try {
            String codigo = txtCodigo.getText().trim();
            String nombre = txtNombre.getText().trim();
            String autor = txtAutor.getText().trim();
            String editorial = txtEditorial.getText().trim();
            String anioTexto = txtAnio.getText().trim();

            if (codigo.isEmpty() || nombre.isEmpty() || autor.isEmpty()
                    || editorial.isEmpty() || anioTexto.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Todos los campos son obligatorios.",
                        "Validación",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            int anio = Integer.parseInt(anioTexto);

            screenManager.agregarLibro(
                    codigo,
                    nombre,
                    autor,
                    editorial,
                    anio
            );

            JOptionPane.showMessageDialog(this,
                    "Libro apilado correctamente.");

            limpiarCampos();
            actualizarVista();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "El año debe ser un número entero.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void sacarLibro() {
        String mensaje = screenManager.retirarLibro();

        JOptionPane.showMessageDialog(this, mensaje);

        actualizarVista();
    }

    private void verTope() {
        String mensaje = screenManager.mostrarTope();

        JOptionPane.showMessageDialog(this,
                mensaje,
                "Libro en el Tope",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void limpiarCampos() {
        txtCodigo.setText("");
        txtNombre.setText("");
        txtAutor.setText("");
        txtEditorial.setText("");
        txtAnio.setText("");

        txtCodigo.requestFocus();
    }

    private void actualizarVista() {
        txtAreaEstante.setText(screenManager.mostrarEstante());
        lblCantidad.setText(
                "Cantidad de libros: " + screenManager.getCantidadLibros()
        );
    }
}
