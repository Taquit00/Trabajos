#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {

    int n;

    cout << "Cuantos numeros aleatorios quieres generar? ";
    cin >> n;

    // Inicializamos la semilla de numeros aleatorios
    srand(time(NULL));

    for (int i = 0; i < n; i++) {

        // Genera un numero entre 10000 y 99000
        int numero = 10000 + rand() % (99000 - 10000 + 1);

        cout << numero << " ";
    }

    return 0;
}

