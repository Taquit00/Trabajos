// C++ program to implement Selection Sort
#include <bits/stdc++.h>
using namespace std;

void selectionSort(vector<int> &arr) {
    int n = arr.size();

    for (int i = 0; i < n - 1; ++i) {

        // Assume the current position holds
        // the minimum element
        int min_idx = i;

        // Iterate through the unsorted portion
        // to find the actual minimum
        for (int j = i + 1; j < n; ++j) {
            if (arr[j] < arr[min_idx]) {

                // Update min_idx if a smaller
                // element is found
                min_idx = j; 
            }
        }

        // Move minimum element to its
        // correct position
        swap(arr[i], arr[min_idx]);
    }
}

void printArray(vector<int> &arr) {
    for (int &val : arr) {
        cout << val << " ";
    }
    cout << endl;
}
/*
EJEMPLO

    vector<int> arr = {64, 25, 12, 22, 11};

    cout << "Original array: ";
    printArray(arr); 

    selectionSort(arr);

    cout << "Sorted array: ";
    printArray(arr);

    return 0;
}
*/

int main() {

    int n;

    // Preguntamos cuantos numeros quiere ordenar
    cout << "Cuantos numeros quieres ordenar? ";
    cin >> n;

    // Creamos el vector
    vector<int> arr(n);

    // Pedimos los numeros al usuario
    for (int i = 0; i < n; i++) {
        cout << "Ingresa el numero " << i + 1 << ": ";
        cin >> arr[i];
    }

    // Mostramos el arreglo original
    cout << "\nArreglo original: ";
    printArray(arr);

    // Ordenamos usando Selection Sort
    selectionSort(arr);

    // Mostramos el arreglo ordenado
    cout << "Arreglo ordenado: ";
    printArray(arr);

    return 0;
}
