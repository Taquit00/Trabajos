// C++ program for implementation of Insertion Sort
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <random>

using namespace std;

/* Function to sort array using insertion sort */
void insertionSort(int arr[], int n)
{
    for (int i = 1; i < n; ++i) {
        int key = arr[i];
        int j = i - 1;

        /* Move elements of arr[0..i-1], that are
           greater than key, to one position ahead
           of their current position */
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

/* A utility function to print array of size n */
void printArray(int arr[], int n)
{
    for (int i = 0; i < n; ++i)
        cout << arr[i] << " ";
    cout << endl;
}

int busquedabinaria(int arr[], int n, int elemento){
	int inicio = 0;
	int fin = n -1;
	
	while (inicio <= fin){
		int medio = (inicio + fin) / 2;
		
		if (arr[medio]== elemento ){
			return medio;
		}
		if (elemento > arr[medio]){
			inicio = medio + 1;
			
		}
		else{
			fin = medio - 1;
			
			
		}
	}
	
}

// Driver method ejemplo
/*
int main()
{
    int arr[] = { 12, 11, 13, 5, 6 };
    int n = sizeof(arr) / sizeof(arr[0]);

    insertionSort(arr, n);
    printArray(arr, n);

    return 0;
}
*/

int main()
{
    int n;
	int elemento;
    cout << "Cuantos numeros aleatorios quieres generar? ";
    cin >> n;

    // Generador de numeros aleatorios
    random_device rd;
    mt19937 generador(rd());

    // Rango: 10000 hasta 99000
    uniform_int_distribution<int> distribucion(10000, 99000);

    int arr[n];

    // Generar numeros
    for (int i = 0; i < n; i++) {
        arr[i] = distribucion(generador);
    }

    // Ordenar
    insertionSort(arr, n);
    
    cout << "Que numero quieres buscar: ";
    cin >> elemento ;
    
    int posicion= busquedabinaria(arr, n, elemento);
    
    if(posicion != -1){
    	cout << "El numero se encuentra en la posicion: "
    	<< posicion << endl;
    	
	}
	else{
		cout <<"El numero no se encuentra en la lista."<<endl;
	}



    return 0;
    
}



